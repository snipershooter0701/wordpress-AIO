<?php

class Instagram extends Downloader
{
    public static $cookieFile = __DIR__ . '/../../cookies/ig-cookie.txt';
    private $postPage;

    public function fetch($videoUrl)
    {
        $data = $this->wsm($videoUrl);
        if ($data['success']) {
            $this->title = $data['title'] ?? 'Instagram Post ' . rand(1, 100);
            $this->thumbnail = $data['thumbnail_src'] ?? null;
            $this->source = 'instagram';
            if (!empty($data['photo'])) {
                foreach ($data['photo'] as $item) {
                    $this->medias[] = new Media($item['direct_url'], 'hd', $item['type'], false, false);
                    if ($this->thumbnail == null) {
                        $this->thumbnail = $item['direct_url'];
                    }
                }
            }
            if (!empty($data['streams'])) {
                foreach ($data['streams'] as $item) {
                    $this->medias[] = new Media($item['direct_url'], 'hd', $item['type'], true, true);
                }
            }
            if ($this->thumbnail != null) {
                $this->saveThumbnail();
                $this->thumbnailHotlinkProtection = true;
            }
        }
    }

    private function wsm($url)
    {
        $msg['success'] = false;
        $msg['body'] = 'Seems like there is nothing here!';
        $fixed_url = explode('?', $url);
        $url = rtrim($fixed_url[0], '/');
        $data0 = json_decode($this->urlGetContents('https://api.instagram.com/oembed/?url=' . $url));
        if (isset($data0->title)) {
            $msg['title'] = $data0->title;
            $msg['thumnail_src'] = $data0->thumbnail_url;
            $msg['success'] = true;
            $src = $data0->thumbnail_url;
            $quality = $data0->thumbnail_width . 'x' . $data0->thumbnail_height;
            $type_p = pathinfo(explode("?", $src)[0], PATHINFO_EXTENSION);
            $msg['photo'][] = ['direct_url' => $src, 'feu_url' => $src, 'type' => $type_p, 'quality' => $quality];
        }
        $data = $this->urlGetContents($url . '/embed/captioned/');
        $json_file = Helpers::getStringBetween($data, "window.__additionalDataLoaded('graphql',", ');');
        $parsed_json = json_decode($json_file);
        $post_page[0] = $parsed_json;
        if ($post_page[0] == '') {
            $json_file = Helpers::getStringBetween($data, "window.__additionalDataLoaded('extra',", ');');
            $parsed_json = json_decode($json_file);
            $post_page[0] = $parsed_json;
        }
        if ($post_page[0] == '') {
            $data = $this->urlGetContents($url);
            $json_file = Helpers::getStringBetween($data, "window._sharedData =", ';</script>');
            $parsed_json = json_decode($json_file);
            $post_page1 = $parsed_json->entry_data->PostPage;
            $post_page[0] = $post_page1[0]->graphql;
        }
        if (isset($post_page[0]->shortcode_media->display_url)) {
            unset($msg['photo']);
            $msg['thumnail_src'] = $post_page[0]->shortcode_media->display_url;
            $msg['success'] = true;
            $src = $post_page[0]->shortcode_media->display_url;
            $quality = 'hd';
            //$quality = $data0->thumbnail_width . 'x' . $data0->thumbnail_height;
            $type_p = pathinfo(explode("?", $src)[0], PATHINFO_EXTENSION);
            $msg['photo'][] = ['direct_url' => $src, 'feu_url' => $src, 'type' => $type_p, 'quality' => $quality];
        }
        if (isset($post_page[0]->shortcode_media->video_url)) {
            $src = $post_page[0]->shortcode_media->video_url;
            $type = pathinfo(explode("?", $src)[0], PATHINFO_EXTENSION);
            $msg['streams'][] = ['direct_url' => $src, 'feu_url' => $src, 'type' => $type, 'quality' => 'HQ'];
        }
        if (!empty($post_page[0]->shortcode_media->edge_sidecar_to_children)) {
            $childrens = $post_page[0]->shortcode_media->edge_sidecar_to_children->edges;
            foreach ($childrens as $child) {
                $child_node = $child->node;
                if ($child_node->is_video === true) {
                    $src = $child_node->video_url;
                    $type_v = pathinfo(explode("?", $src)[0], PATHINFO_EXTENSION);
                    $msg['streams'][] = ['direct_url' => $src, 'feu_url' => $src, 'type' => $type_v, 'quality' => 'HQ'];
                } else {
                    $src = $child_node->display_url;
                    $quality = $child_node->dimensions->width . 'x' . $child_node->dimensions->height;
                    $type_p = pathinfo(explode("?", $src)[0], PATHINFO_EXTENSION);
                    $msg['photo'][] = ['direct_url' => $src, 'feu_url' => $src, 'type' => $type_p, 'quality' => $quality];
                }
            }
        }
        if (empty($msg['photo']) and !empty($post_page[0]->shortcode_media->display_resources)) {
            $resurces = $post_page[0]->shortcode_media->display_resources;
            foreach ($resurces as $resurce) {
                $src = $resurce->src;
                $quality = $resurce->config_width . 'x' . $resurce->config_height;
                $type_p = pathinfo(explode("?", $src)[0], PATHINFO_EXTENSION);
                $msg['photo'][] = ['direct_url' => $src, 'feu_url' => $src, 'type' => $type_p, 'quality' => $quality];
            }
        }
        if (empty($msg['photo'][1]) and $msg['success'] == false) {
            $data = $this->urlGetContents($url . '/embed/');
            $first_extract = Helpers::getStringBetween(str_replace('&amp;', '&', $data), '<img class="EmbeddedMediaImage"', '/>');
            $second = Helpers::getStringBetween($first_extract, 'srcset="', '"');
            $exloded = explode(",", $second);
            $msg['success'] = true;
            foreach ($exloded as $explod1) {
                $extract = explode(' ', $explod1);
                $size = null;
                $msg['photo'][] = ['direct_url' => $extract[0], 'feu_url' => $extract[0], 'type' => 'jpg', 'quality' => $extract[1], 'size' => $size];
                $msg['thumnail_src'] = $extract[0];
                if ($size == 0 || $size == '-1') {
                    $msg['success'] = false;
                    $msg['body'] = 'Seems like there is nothing here!';
                }
            }
        }
        return $msg;
    }

    public function fetch2($videoUrl)
    {
        $videoUrl = preg_replace('/\/reel\//', '/tv/', $videoUrl);
        $videoUrl = strtok($videoUrl, '?');
        if (substr($videoUrl, -1) != '/') {
            $videoUrl .= '/';
        }
        $this->source = 'instagram';
        preg_match('/https:\/\/www.instagram.com\/reel\/(.*?)\//', $videoUrl, $isReel);
        if (!empty($isReel[1])) {
            $videoUrl = str_replace('/reel/', '/p/', $videoUrl);
            $this->postPage = $this->urlGetContents($videoUrl);
            $data = $this->parsePostPage($this->postPage);
            if (!empty($data)) {
                $this->title = $data['title'];
                $this->thumbnail = $data['thumbnail'];
                $this->medias[] = $data['medias'];
                $this->saveThumbnail();
                $this->thumbnailHotlinkProtection = true;
            }
        } else {
            $this->postPage = $this->urlGetContents($videoUrl);
            if (strpos($this->postPage, 'WatchOnInstagram')) {
                $this->mediaInfoLegacy($videoUrl);
            }
            $data = $this->parsePostPage2($this->postPage);
            if (!empty($data)) {
                if (empty($data['sidecar'])) {
                    $this->title = $data['title'];
                    $this->thumbnail = $data['thumbnail'];
                    $this->medias = $data['medias'];
                } else {
                    if ($data['shortcode_media']['__typename'] == 'GraphSidecar') {
                        $multipleData = $data['shortcode_media']['edge_sidecar_to_children']['edges'];
                        foreach ($multipleData as $media) {
                            $audioAvailable = false;
                            $mediaUrl = null;
                            if ($media['node']['is_video'] == 'true') {
                                if (!empty($media['node']['video_url'])) {
                                    $mediaUrl = $media['node']['video_url'];
                                    $type = 'mp4';
                                    $audioAvailable = true;
                                } else {
                                    $postPage = $this->urlGetContents('https://www.instagram.com/p/' . $media['node']['shortcode']);
                                    $data = $this->parsePostPage($postPage);
                                    if (!empty($data['medias'])) {
                                        $this->medias = array_merge($this->medias, $data['medias']);
                                        continue;
                                    }
                                }
                            } else {
                                $length = count($media['node']['display_resources']);
                                $mediaUrl = $media['node']['display_resources'][$length - 1]['src'];
                                $type = 'jpg';
                            }
                            if ($mediaUrl === null) {
                                continue;
                            }
                            $this->medias[] = new Media($mediaUrl, 'hd', $type, true, $audioAvailable);
                        }
                    } else {
                        if ($data['shortcode_media']['__typename'] == 'GraphVideo') {
                            $this->medias[] = new Media($data['shortcode_media']['video_url'], 'hd', 'mp4', true, true);
                        }
                    }
                }
            }
            $this->title = Helpers::truncateString($this->title);
            $this->thumbnail = html_entity_decode($this->thumbnail);
            $this->saveThumbnail();
            $this->thumbnailHotlinkProtection = true;
        }
    }

    private function parsePostPage($postPage)
    {
        $result = [];
        preg_match_all('/window._sharedData = (.*);<\/script>/', $postPage, $matches);
        if (!empty($matches[1][0])) {
            $data = json_decode($matches[1][0], true);
            if (!empty($data['entry_data']['PostPage'][0]['graphql']['shortcode_media'])) {
                $data = $data['entry_data']['PostPage'][0]['graphql']['shortcode_media'];
                $result['title'] = 'Instagram Video';
                $result['thumbnail'] = html_entity_decode($data['display_url']);
                $result['medias'] = [];
                $result['medias'][] = new Media($data['video_url'], 'hd', 'mp4', true, true);
            }
        } else {
            $result = $this->parsePostPage2($postPage);
        }
        return $result;
    }

    private function parsePostPage2($postPage)
    {
        $result = [];
        preg_match_all('/window\.__additionalDataLoaded\(\'.*\',(.*?)\);/', $postPage, $matches);
        if (isset($matches[1][0]) != '') {
            $data = json_decode($matches[1][0], true);
            $result['medias'] = [];
            //print_r($data);
            if (!empty($data['shortcode_media'])) {
                preg_match_all('/<img class="EmbeddedMediaImage" alt=".*" src="(.*?)"/', $postPage, $matches);
                if (isset($matches[1][0]) != '') {
                    $result['title'] = Helpers::getStringBetween($postPage, '<img class="EmbeddedMediaImage" alt="', '"');
                    $result['thumbnail'] = $matches[1][0];
                    $mediaUrl = html_entity_decode($matches[1][0]);
                    $result['medias'][] = new Media($mediaUrl, 'hd', 'jpg', true, false);
                } else {
                    $result['title'] = $data['shortcode_media']['edge_media_to_caption']['edges'][0]['node']['text'] ?? '';
                    if (empty($result['title']) && isset($data['shortcode_media']['owner']['username']) != '') {
                        $result['title'] = 'Instagram Post from ' . $data['shortcode_media']['owner']['username'];
                    } else {
                        $result['title'] = 'Instagram Post';
                    }
                    $result['thumbnail'] = $data['shortcode_media']['display_resources'][0]['src'];
                    if ($data['shortcode_media']['__typename'] == "GraphImage") {
                        $imagesData = $data['shortcode_media']['display_resources'];
                        $length = count($imagesData);
                        $result['medias'][] = new Media($imagesData[$length - 1]['src'], 'hd', 'jpg', true, false);
                    } else {
                        $result['sidecar'] = true;
                        $result['data'] = $data;
                    }
                }
            } else if (!empty($data['items'])) {
                $result['medias'] = [];
                foreach ($data['items'] as $item) {
                    $result['title'] = $item['caption']['text'] ?? "Instagram Post";
                    if (!empty($item['carousel_media'])) {
                        $result['thumbnail'] = $item['carousel_media'][0]['image_versions2']['candidates'][0]['url'];
                        foreach ($item['carousel_media'] as $carouselMedia) {
                            if (!empty($carouselMedia['video_versions'])) {
                                foreach ($carouselMedia['video_versions'] as $video) {
                                    $result['medias'][] = new Media($video['url'], $video['height'] . 'p', 'mp4', true, true);
                                }
                            }
                            if (!empty($carouselMedia['image_versions2']['candidates'])) {
                                $result['medias'][] = new Media($carouselMedia['image_versions2']['candidates'][0]['url'], 'hd', 'jpg', false, false);
                            }
                        }
                    } else if (!empty($item['video_versions'])) {
                        $result['thumbnail'] = $item['image_versions2']['candidates'][0]['url'];
                        foreach ($item['video_versions'] as $video) {
                            $result['medias'][] = new Media($video['url'], $video['height'] . 'p', 'mp4', true, true);
                        }
                    } else {
                        $result['thumbnail'] = $item['image_versions2']['candidates'][0]['url'];
                        $result['medias'][] = new Media($item['image_versions2']['candidates'][0]['url'], 'hd', 'jpg', false, false);
                    }
                }
            }
        }
        return $result;
    }

    function mediaInfoLegacy($url)
    {
        $this->postPage = $this->urlGetContents($url);
        $this->source = 'instagram';
        $mediaInfo = $this->mediaData($this->postPage);
        if (empty($mediaInfo)) {
            $data = $this->parsePostPage2($this->postPage);
            if (!empty($data['medias'])) {
                $this->title = $data['title'];
                $this->thumbnail = $data['thumbnail'];
                $this->medias[] = $data['medias'];
                $this->saveThumbnail();
                $this->thumbnailHotlinkProtection = true;
            }
        } else {
            $this->title = $this->getTitle($this->postPage);
            $this->thumbnail = $this->getThumbnail($this->postPage);
            $this->saveThumbnail();
            $this->thumbnailHotlinkProtection = true;
            foreach ($mediaInfo['links'] as $link) {
                if (empty($link['type'])) {
                    continue;
                }
                switch ($link['type']) {
                    case 'video':
                        $this->medias[] = new Media($link['url'], 'hd', 'mp4', true, true);
                        break;
                    case 'image':
                        $this->medias[] = new Media($link['url'], 'hd', 'jpg', true, false);
                        break;
                    default:
                        break;
                }
            }
        }
    }

    private function saveThumbnail()
    {
        $id = sha1($this->thumbnail);
        $cache = new Cache('ig-' . $id, 'jpg', $this->urlGetContents($this->thumbnail));
        $this->thumbnail = $cache->url;
    }

    private function urlGetContents($url)
    {
        //return file_get_contents(__DIR__ . '/ig.html');
        $http = new Http($url);
        $http->addCurlOption(CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4);
        if (file_exists(self::$cookieFile)) {
            $http->addCurlOption(CURLOPT_COOKIEFILE, self::$cookieFile);
        }
        $http->run();
        return $http->response;
    }

    function mediaData($postPage)
    {
        preg_match_all("/window.__additionalDataLoaded.'.{5,}',(.*).;/", $postPage, $matches);
        if (!$matches) {
            return false;
        } else {
            preg_match_all("/window.__additionalDataLoaded.'.{5,}',(.*).;/", $postPage, $matches);
            preg_match_all('/<script type="text\/javascript">window._sharedData = (.*?);<\/script>/', $postPage, $output);
            if (isset($matches[1][0]) != '') {
                $json = $matches[1][0];
            } else if (isset($output[1][0]) != '') {
                $json = $output[1][0];
            }
            $data = json_decode($json, true);
            if (!empty($data['entry_data']['PostPage'][0]['graphql'])) {
                $data = $data['entry_data']['PostPage'][0];
            }
            if (empty($data['graphql'])) {
                return false;
            }
            if ($data['graphql']['shortcode_media']['__typename'] == 'GraphImage') {
                $imagesData = $data['graphql']['shortcode_media']['display_resources'];
                $length = count($imagesData);
                $mediaInfo['links'][0]['type'] = 'image';
                $mediaInfo['links'][0]['url'] = $imagesData[$length - 1]['src'];
                $mediaInfo['links'][0]['status'] = 'success';
            } else {
                if ($data['graphql']['shortcode_media']['__typename'] == "GraphSidecar") {
                    $counter = 0;
                    $multipledata = $data['graphql']['shortcode_media']['edge_sidecar_to_children']['edges'];
                    foreach ($multipledata as $media) {
                        if ($media['node']['is_video'] == 'true') {
                            $mediaInfo['links'][$counter]["url"] = $media['node']['video_url'];
                            $mediaInfo['links'][$counter]["type"] = 'video';
                        } else {
                            $length = count($media['node']['display_resources']);
                            $mediaInfo['links'][$counter]["url"] = $media['node']['display_resources'][$length - 1]['src'];
                            $mediaInfo['links'][$counter]["type"] = 'image';
                        }
                        $counter++;
                        $mediaInfo['type'] = 'media';
                    }
                    $mediaInfo['status'] = 'success';
                } else {
                    if ($data['graphql']['shortcode_media']['__typename'] == 'GraphVideo') {
                        $videolink = $data['graphql']['shortcode_media']['video_url'];
                        $mediaInfo['links'][0]['type'] = 'video';
                        $mediaInfo['links'][0]['url'] = $videolink;
                        $mediaInfo['links'][0]['status'] = 'success';
                    } else {
                        $mediaInfo['links']['status'] = 'fail';
                    }
                }
            }
            return $mediaInfo;
        }
    }

    function getThumbnail($postPage)
    {
        preg_match_all("/window.__additionalDataLoaded.'.{5,}',(.*).;/", $postPage, $matches);
        preg_match_all('/<script type="text\/javascript">window._sharedData = (.*?);<\/script>/', $postPage, $output);
        if (isset($matches[1][0]) != '') {
            $json = $matches[1][0];
        } else if (isset($output[1][0]) != '') {
            $json = $output[1][0];
        }
        $data = json_decode($json, true);
        if (!empty($data['entry_data']['PostPage'][0]['graphql'])) {
            $data = $data['entry_data']['PostPage'][0];
        }
        return $data['graphql']['shortcode_media']['display_resources'][0]['src'];
    }

    function getTitle($postPage)
    {
        $title = '';
        if (preg_match_all('@<title>(.*?)</title>@si', $postPage, $match)) {
            $title = $match[1][0];
        }
        return $title;
    }
}