<?php

class Snapchat extends Downloader
{
    public function fetch($videoUrl)
    {
        $http = new Http($videoUrl);
        $http->run();
        preg_match_all('/<script id="__NEXT_DATA__" type="application\/json">(.*?)<\/script>/', $http->response, $matches);
        if (!empty($matches[1][0])) {
            $data = json_decode($matches[1][0], true);
            if (!empty($data['props']['pageProps']['preselectedStory']['premiumStory']['playerStory']['snapList'])) {
                $data = $data['props']['pageProps']['preselectedStory']['premiumStory']['playerStory'];
                $this->title = $data['storyTitle']['value'];
                $this->source = 'snapchat';
                $this->thumbnail = $data['thumbnailUrl']['value'];
                $this->medias[] = new Media($data['snapList'][0]['snapUrls']['mediaUrl'], 'hd', 'mp4', true, true);
            }
        }
    }
}