<?php

class Facebook extends Downloader
{
    private $cookies = '';

    public function fetch($videoUrl)
    {
        $host = parse_url($videoUrl, PHP_URL_HOST);
        if ($host === 'fb.watch') {
            $destination = $this->getLocation($videoUrl);
            if ($destination !== null) {
                $videoUrl = $destination;
            }
        }
        $this->cookies = get_option('aiodl_facebook_cookies');
        $fb = new Facebook2();
        $fb->cookies = $this->cookies;
        $data = $fb->download($videoUrl);
        if (!empty($data['links'])) {
            $this->title = !empty($data['title']) ? $data['title'] : 'Facebook Video '. rand(1, 100);
            $this->thumbnail = $data['thumbnail'];
            $this->source = 'facebook';
            $this->duration = $data['duration'];
            $N = count($data['links']);
            for ($i = 0; $i < $N; ++$i) {
                $this->medias[] = new Media($data['links'][$i]['url'], $data['links'][$i]['quality'], 'mp4', true, true);
            }
        }
    }

    private function getLocation($shortUrl)
    {
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => $shortUrl,
            CURLOPT_USERAGENT => Http::$userAgent,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HEADER => true,
            CURLOPT_NOBODY => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => false,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'GET',
            CURLOPT_HTTPHEADER => array(
                'authority: fb.watch',
                'sec-ch-ua: "Chromium";v="106", "Google Chrome";v="106", "Not;A=Brand";v="99"',
                'sec-ch-ua-mobile: ?0',
                'sec-ch-ua-platform: "Windows"',
                'sec-fetch-dest: document',
                'sec-fetch-mode: navigate',
                'sec-fetch-site: none',
                'sec-fetch-user: ?1',
                'upgrade-insecure-requests: 1',
            ),
        ));
        $response = curl_exec($curl);
        curl_close($curl);
        preg_match_all('/^Location:(.*)$/mi', $response, $matches);
        if (!empty($matches[1][0])) {
            return trim($matches[1][0]);
        } else {
            return null;
        }
    }

}

class Facebook2
{
    public $cookies = '';

    function fb_get_contents($url)
    {
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'GET',
            CURLOPT_HTTPHEADER => array(
                'authority: www.facebook.com',
                'cache-control: max-age=0',
                'sec-ch-ua: "Google Chrome";v="89", "Chromium";v="89", ";Not A Brand";v="99"',
                'sec-ch-ua-mobile: ?0',
                'upgrade-insecure-requests: 1',
                'user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.114 Safari/537.36',
                'accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
                'sec-fetch-site: none',
                'sec-fetch-mode: navigate',
                'sec-fetch-user: ?1',
                'sec-fetch-dest: document',
                'accept-language: en-GB,en;q=0.9,tr-TR;q=0.8,tr;q=0.7,en-US;q=0.6',
                'cookie: ' . $this->cookies
            ),
        ));
        $response = curl_exec($curl);
        curl_close($curl);
        return $response;
    }

    function download($url)
    {
        $api_key = $this->cookies;
        if (!empty($api_key)) {
            $url = $this->get_original_url($this->remove_mfb($url));
            $url = 'https://www.facebook.com/' . $this->getID(urldecode($url));
            $get_source = $this->fb_get_contents($url, $api_key);
            preg_match_all('/<script type="application\/ld\+json" nonce="\w{3,10}">(.*?)<\/script><link rel="canonical"/', $get_source, $matches);
            preg_match_all('/"video":{(.*?)},"video_home_www_injection_related_chaining_section"/', $get_source, $matches2);
            preg_match_all('/"playable_url":"(.*?)"/', $get_source, $matches3);
            $video['source'] = 'Facebook';
            $video['duration'] = ($this->getDuration($get_source)) ? $this->getDuration($get_source) : null;
            $video['links'] = [];
            if (!empty($matches[1][0])) {
                $data = json_decode($matches[1][0], true);
                if (empty($data) || $data['@type'] != 'VideoObject') {
                    return false;
                }
                $video['title'] = $data['name'];
                $thumbnail = file_get_contents($data['thumbnailUrl']);
                $dataBase64 = 'data:image/jpeg;base64,' . base64_encode($thumbnail);
                $video['thumbnail'] = $dataBase64;
                if (!empty($data['contentUrl'])) {
                    $token['url'] = $data['contentUrl'];
                    $video['links'][] = [
                        'url' => $token['url'],
                        'type' => 'mp4',
                        'quality' => '360p',
                        'mute' => false
                    ];
                }
                $hd_link = Helpers::getStringBetween($get_source, 'hd_src:"', '"');
                if (!empty($hd_link)) {
                    $token['url'] = $hd_link;
                    $video['links'][] = [
                        'url' => $token['url'],
                        'type' => 'mp4',
                        'quality' => '720p',
                        'mute' => false
                    ];
                }
            } else if (!empty($matches2[1][0])) {
                $json = "{" . $matches2[1][0] . "}";
                $data = json_decode($json, true);
                if (empty($data) || !!empty($data['story']['attachments'][0]['media']['__typename']) || $data['story']['attachments'][0]['media']['__typename'] != 'Video') {

                    return false;
                }
                $video['title'] = $data['story']['message']['text'];
                $thumbnail = file_get_contents($data['story']['attachments'][0]['media']['thumbnailImage']['uri']);
                $dataBase64 = 'data:image/jpeg;base64,' . base64_encode($thumbnail);
                $video['thumbnail'] = $dataBase64;
                if (!empty($data['story']['attachments'][0]['media']['playable_url'])) {
                    $token['url'] = $data['story']['attachments'][0]['media']['playable_url'];
                    $video['links'][] = [
                        'url' => $token['url'],
                        'type' => 'mp4',
                        'quality' => '360p',
                        'mute' => false
                    ];
                }
                if (!empty($data['story']['attachments'][0]['media']['playable_url_quality_hd'])) {
                    $token['url'] = $data['story']['attachments'][0]['media']['playable_url_quality_hd'];
                    $video['links'][] = [
                        'url' => $token['url'],
                        'type' => 'mp4',
                        'quality' => '720p',
                        'mute' => false
                    ];
                }
            } else if (!empty($matches3[1][0])) {
                preg_match('/"preferred_thumbnail":{"image":{"uri":"(.*?)"/', $get_source, $thumbnail);
                preg_match_all('/"playable_url_quality_hd":"(.*?)"/', $get_source, $hd_link);
                $video['title'] = 'Facebook Video';
                $thumbnail = file_get_contents(!empty($thumbnail[1]) ? $this->decode_json_text($thumbnail[1]) : '');
                $dataBase64 = 'data:image/jpeg;base64,' . base64_encode($thumbnail);
                $video['thumbnail'] = $dataBase64;
                $sd_link = $this->decode_json_text($matches3[1][0]);
                $token['url'] = $sd_link;
                $video['links'][] = [
                    'url' => $token['url'],
                    'type' => 'mp4',
                    'quality' => '360p',
                    'mute' => false
                ];
                if (!empty($hd_link[1][0])) {
                    $hd_link = $this->decode_json_text($hd_link[1][0]);
                    $token['url'] = $hd_link;
                    $video['links'][] = [
                        'url' => $token['url'],
                        'type' => 'mp4',
                        'quality' => '720p',
                        'mute' => false
                    ];
                }
            } else {
                return false;
            }
            //usort($video['links'], array('Helpers', 'sortByQuality'));
            return $video;
        }
    }

    function get_original_url($url, $maxRedirs = 3)
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_HEADER, true);
        curl_setopt($ch, CURLOPT_NOBODY, true);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_MAXREDIRS, $maxRedirs);
        curl_setopt($ch, CURLOPT_TIMEOUT, 15);
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'authority: www.facebook.com',
            'cache-control: max-age=0',
            'sec-ch-ua: "Google Chrome";v="89", "Chromium";v="89", ";Not A Brand";v="99"',
            'sec-ch-ua-mobile: ?0',
            'upgrade-insecure-requests: 1',
            'user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.114 Safari/537.36',
            'accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
            'sec-fetch-site: none',
            'sec-fetch-mode: navigate',
            'sec-fetch-user: ?1',
            'sec-fetch-dest: document',
            'accept-language: en-GB,en;q=0.9,tr-TR;q=0.8,tr;q=0.7,en-US;q=0.6',
            'cookie: ' . $this->cookies
        ));
        curl_exec($ch);
        $longUrl = curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);
        curl_close($ch);
        parse_str(parse_url($longUrl, PHP_URL_QUERY), $query);
        if (!empty($query['next'])) {
            return $query['next'];
        } else {
            return $longUrl;
        }
    }

    function getID($url)
    {
        if (preg_match('/\/(.*)\/videos\/(.*)\/(.*)\/([0-9]+)/U', $url, $matches)) {
            //https://www.facebook.com/username/videos/vb.user_id/video_id/
            $id = $matches[3];
        } elseif (preg_match('/\/(.*)\/videos\/(.*)\/([0-9]+)/', $url, $matches)) {
            //https://www.facebook.com/username/videos/video_id
            $id = $matches[3];
        } elseif (preg_match('/\/(.*)\/videos\/(.*)\/([0-9]+)/U', $url, $matches)) {
            //https://www.facebook.com/username/videos/video_id
            $id = $matches[2];
        } elseif (preg_match('/\/video\.php\?v\=([0-9]+)/', $url, $matches)) {
            //https://www.facebook.com/video.php?v=video_id
            $id = $matches[1];
        } elseif (preg_match('/\/watch\/\?v\=([0-9]+)/', $url, $matches)) {
            //https://www.facebook.com/watch/?v=video_id
            $id = $matches[1];
        } elseif (preg_match('/^(?:(?:https?:)?\/\/)?(?:www\.)?facebook\.com\/[a-zA-Z0-9\.]+\/videos\/(?:[a-zA-Z0-9\.]+\/)?([0-9]+)/', $url, $matches)) {
            $id = $matches[1];
        } elseif (preg_match('/(?:\.?\d+)(?:\/videos)?\/?(\d+)?(?:[v]\=)?(\d+)?/i', $url, $matches)) {
            $id = $matches[0];
        }
        return $id;
    }

    function decode_json_text($text)
    {
        $json = '{"text":"' . $text . '"}';
        $json = json_decode($json, 1);
        return $json["text"];
    }

    function getDuration($curl_content)
    {
        $regexDuration = '/"duration":"(.*?)"/';
        if (preg_match($regexDuration, $curl_content, $match)) {
            return str_replace('\/', '/', $match[1]);
        }
    }

    function remove_mfb($url)
    {
        $url = str_replace('m.facebook.com', 'www.facebook.com', $url);
        return $url;
    }
}