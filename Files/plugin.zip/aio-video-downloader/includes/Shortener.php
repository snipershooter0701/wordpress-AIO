<?php

abstract class Shortener {
    public static $API_URL = null;
    public $API_KEY = null;
    public static $NAME = null;

    public function __construct($apiKey)
    {
        $this->API_KEY = $apiKey;
    }

    public abstract function shorten($url);
}