<?php
/**
 * Plugin Name: All in One Video Downloader
 * Version: 2.7.0
 * Plugin URI: https://aiovideodl.ml/
 * Description: All in One Video Downloader
 * Author: Niche Office
 * Author URI: https://support.nicheoffice.web.tr/
 * Requires at least: 4.0
 * Tested up to: 4.0
 *
 * Text Domain: all-in-one-video-downloader
 * Domain Path: /lang/
 *
 * @package WordPress
 * @author Niche Office
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

// Load plugin class files.
require_once 'includes/class-all-in-one-video-downloader.php';
require_once 'includes/class-all-in-one-video-downloader-settings.php';

// Load plugin libraries.
require_once 'includes/lib/class-all-in-one-video-downloader-admin-api.php';
require_once 'includes/lib/class-all-in-one-video-downloader-post-type.php';
require_once 'includes/lib/class-all-in-one-video-downloader-taxonomy.php';
require_once 'includes/lib/class-all-in-one-video-downloader-downloaders.php';
require_once 'includes/lib/class-all-in-one-video-downloader-routes.php';

define('AUTOSAVE_INTERVAL', 300);
define('WP_POST_REVISIONS', false);

/**
 * Returns the main instance of All_in_One_Video_Downloader to prevent the need to use globals.
 *
 * @return object All_in_One_Video_Downloader
 * @since  1.0.0
 */
function all_in_one_video_downloader()
{
    $instance = All_in_One_Video_Downloader::instance(__FILE__, '2.7.0');

    if (is_null($instance->settings)) {
        $instance->settings = All_in_One_Video_Downloader_Settings::instance($instance);
    }

    return $instance;
}

define('AIO_VIDEO_DOWNLOADER_VERSION', 'MTkwMzIyLjE1NzcwMi44OTQwNy4yNzAwMA==6');
all_in_one_video_downloader();